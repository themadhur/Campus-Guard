# Campus Guard

> **Report. Track. Improve.**  
> A smart campus issue reporting and facilities management platform for colleges and universities.

---

## 🚀 Features

- **Student Incident Reporting**: Quick form with photo upload, campus location (Building, Floor, Room), and issue description.
- **AI-Assisted Triage**: Multimodal AI analysis (powered by Google Gemini `gemini-3.8-flash`) automatically categorizes issues, assesses urgency, and routes them to the right department (Electrical, Plumbing, IT, Maintenance, Housekeeping, etc.).
- **Local Fallback Classifier**: Keyword and heuristic engine ensures reporting works 100% of the time, even without an AI key or network connection.
- **Complaint Tracking**: Real-time progress timeline (`Submitted` → `Under Review` → `Assigned` → `In Progress` → `Resolved`) using unique tracking IDs (`CG-2026-XXXXX`).
- **Student Authentication & Profiles**: Sign in with Email/Password, Google OAuth, or 1-Click Demo Login. View personal history in the **My Reports** tab.
- **Facilities Admin Portal**: KPI metrics, category & department workload distribution charts, live search/filtering, status transitions, and audit activity logging.
- **Resilient Dual-Persistence**: Firestore cloud database support with offline-first local storage caching.

---

## 📦 Project Setup & Installation

1. **Clone or Extract Archive**:
   ```bash
   unzip campus-guard.zip
   cd campus-guard
   ```

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Environment Variables**:
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Add your Gemini API Key:
   ```env
   GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
   ```

4. **Run the Development Server**:
   ```bash
   npm run dev
   ```
   The app will start on `http://localhost:3000`.

5. **Build for Production**:
   ```bash
   npm run build
   npm start
   ```

---

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS 4, Lucide Icons, Motion
- **Backend**: Node.js, Express, Vite middleware
- **AI**: `@google/genai` TypeScript SDK (`gemini-3.8-flash`)
- **Database & Auth**: Firebase Firestore & Firebase Authentication
- **Image Processing**: HTML5 Canvas client-side compression + Firebase Storage
